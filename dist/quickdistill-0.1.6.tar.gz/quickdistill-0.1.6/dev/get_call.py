# import weave
# client = weave.init("byyoung3/arena-detailed")
# call = client.get_call("019b6c3d-a7cd-7c7b-9fff-9ebb05298ec9")

# print(call)


import weave
client = weave.init("byyoung3/arena-detailed")
call = client.get_call("019b6c3d-7ade-7105-af04-432053fd9da3")
print(call)